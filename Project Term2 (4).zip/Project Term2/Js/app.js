let navbarList = document.getElementById("navbar__list");
let sections = document.querySelectorAll("section");
sections.forEach((section) => {
  let listItem = document.createElement("li");
  let anchor = document.createElement("a");
  anchor.href = `#${section.id}`;
  anchor.textContent = section.getAttribute("data-nav");
  listItem.appendChild(anchor);
  navbarList.appendChild(listItem);
});

document.addEventListener("scroll", () => {
  let currentSection = getClosestSection();
  highlightSection(currentSection);
});

function getClosestSection() {
  let sections = document.querySelectorAll("section");
  let scrollPosition = window.scrollY + window.innerHeight / 2;
  let closestSection = null;
  let closestDistance = Infinity;

  sections.forEach((section) => {
    let sectionTop = section.offsetTop;
    let sectionHeight = section.offsetHeight;
    let distance = Math.abs(scrollPosition - (sectionTop + sectionHeight / 2));

    if (distance < closestDistance) {
      closestDistance = distance;
      closestSection = section;
    }
  });

  return closestSection;
}

function highlightSection(section) {
  let navbarItems = document.querySelectorAll("#navbar__list li");
  navbarItems.forEach((item) => {
    item.classList.remove("active");
  });

  let anchor = document.querySelector(`#navbar__list a[href="#${section.id}"]`);
  anchor.parentNode.classList.add("active");
}

const navbarListItems = document.querySelectorAll('.navbar__menu li');

navbarListItems.forEach((listItem) => {
  listItem.addEventListener('click', (e) => {
    e.preventDefault();
    const href = e.target.getAttribute('href');
    const targetElement = document.querySelector(href);
    targetElement.scrollIntoView({ behavior: 'smooth' });
  });
});

const commentInput = document.getElementById('comment-input');
const addCommentBtn = document.getElementById('add-comment-btn');
const usernameInput = document.getElementById('username-input');
const emailInput = document.getElementById('email-input');

let comments = [];

function generateUniqueId() {
  return Math.random().toString(36).substr(2, 9);
}

function validateInput(text) {
  return text.trim() !== '';
}

function addComment(username, email, text) {
  const newComment = {
    username,
    email,
    text,
    id: generateUniqueId()
  };
  comments.push(newComment);
  renderComments();
  usernameInput.value = '';
  emailInput.value = '';
  commentInput.value = '';
}

function deleteComment(id) {
  comments = comments.filter((comment) => comment.id !== id);
  renderComments();
}

function renderComments() {
  const commentsList = document.getElementById('comments-list');
  commentsList.innerHTML = '';
  comments.forEach((comment) => {
    const commentHTML = `
      <li>
        <span class="username">${comment.username} (${comment.email})</span>
        <p>${comment.text}</p>
        <button class="delete-btn" data-id="${comment.id}">Delete</button>
      </li>
    `;
    commentsList.insertAdjacentHTML('beforeend', commentHTML);
  });
}

const commentForm = document.getElementById('comment-form');
commentForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const username = usernameInput.value.trim();
  const email = emailInput.value.trim();
  const comment = commentInput.value.trim();

  if (username && email && comment) {
    addComment(username, email, comment);
  }
});

const commentsList = document.getElementById('comments-list');
commentsList.addEventListener('click', (e) => {
  if (e.target.classList.contains('delete-btn')) {
    const commentId = e.target.dataset.id;
    deleteComment(commentId);
  }
});

renderComments();